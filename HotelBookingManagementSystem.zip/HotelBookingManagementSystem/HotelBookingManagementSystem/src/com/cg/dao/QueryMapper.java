package com.cg.dao;

public interface QueryMapper 
{
//**********************Hotel Management Queries***************************//
	String INSERT_HOTEL="INSERT INTO HOTEL VALUES(?,?,?,?,?,?,?,?,?,?,?)";
	String DELETE_HOTEL="DELETE FROM HOTEL WHERE hotel_id=?";
	String UPDATE_HOTEL="UPDATE hotel SET city=?,hotel_name=?,address=?,description=?,"
			+ "avg_rate_per_night=?,phone_no1=?,phone_no2=?,"
			+ "rating=?,email=?,fax=? WHERE hotel_id=?";
	String SEQUENCE="SELECT htl_id_seq.NEXTVAL FROM DUAL";
//*************Room Management Queries****************************//
	String ADD_ROOM="INSERT INTO roomdetails VALUES(?,?,?,?,?,?)";
	String DELETE_ROOM="DELETE FROM roomdetails WHERE hotel_id=? and room_id=?";
	String UPDATE_ROOM="UPDATE roomdetails SET room_no=?,room_type=?,per_night_rate=?,"
			+ "availability=? where room_id=?";
//******************Reports Queries**********************//
	String VIEW_HOTELS="SELECT *FROM hotel";
	String VIEW_BOOKINGS_HOTEL="";
	String VIEW_GUEST_HOTEL="SELECT u.user_id FROM users u, hotel h, bookingdetails b, roomdetails r WHERE b.room_id = r.room_id AND u.user_id = b.user_id"
			    +"AND r.hotel_id = h.hotel_id AND h.hotel_id=?";
	String VIEW_BOOKING_DATE="SELECT * FROM bookingdetails WHERE booked_from=?";
	String SELECT_USER="SELECT * FROM users WHERE user_id=?";
	String BOOKING_CHECK="select booking_id from bookingdetails b join roomdetails r "
            + "on b.room_id=r.room_id where hotel_id=?";
    String SPECIFIC_HOTEL_BOOKING_DETAILS="select * from bookingdetails where booking_id=?";
	
//******************Search Hotel Queries************************//
	String SEARCH_HOTEL="SELECT * FROM Hotel WHERE city=?";
//******************User Login and Register Queries************************//
	String USER_LOGIN="SELECT * FROM users WHERE user_id=? AND password=?";
	String USER_REGISTER="INSERT INTO users VALUES(?,?,?,?,?,?,?,?)";
	String BILL_QUERY="SELECT per_night_rate FROM roomdetails WHERE room_id=?";

    String SHOW_ROOMS="SELECT * FROM roomdetails r JOIN hotel h "
            + "ON h.hotel_id=r.hotel_id WHERE h.hotel_name=? AND r.availability='yes'";
    String INSERT_BOOKINGDETAILS="insert into BookingDetails values(?,?,?,?,?,?,?,?)";
    String BOOKING_SEQUENCE="SELECT booking_seq.NEXTVAL FROM DUAL";
}
