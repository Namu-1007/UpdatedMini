package com.cg.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.bean.User;
import com.cg.exception.HotelException;

public interface UserDao 
{
	public boolean login(User user) throws HotelException;

	public int registerUser(User user) throws HotelException;

	public ArrayList<Hotels> searchAllHotels(String city) throws HotelException;

	public ArrayList<RoomDetails> showRooms(String hotelname)throws HotelException; 

	public double generateBill(String roomId, LocalDate bookFrom,LocalDate bookTo) throws
	HotelException;

	public int bookHotel(BookingDetails bookingDetails) throws HotelException;
	
	public ArrayList<BookingDetails> getBookingStatus(String booking_id) throws HotelException;
}
