package com.cg.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.bean.User;
import com.cg.dao.AdminDao;
import com.cg.dao.AdminDaoImpl;
import com.cg.exception.HotelException;


public class AdminServiceImpl implements AdminService
{
	AdminDao hdao=null;
	public AdminServiceImpl()
	{
		hdao=new AdminDaoImpl();
	}
	@Override
	public int addHotels(Hotels htl) throws HotelException 
	{
		return hdao.addHotels(htl);
	}
	@Override
	public int updateHtl(Hotels hotel) throws HotelException 
	{
		return hdao.updateHtl(hotel);
	}
	@Override
	public boolean validateAdmName(String cName) throws HotelException 
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,cName))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Name");
		}
	}
	@Override
	public boolean validateAdmPass(String adPass) throws HotelException
	{
		String namePattern="admin";
		if(Pattern.matches(namePattern,adPass))
		{
			return true;
		}
		else
		{
			throw new HotelException("Invalid Password");
		}
	}
	@Override
	public String generateHotelId() throws HotelException 
	{
		return hdao.generateHotelId();
	}
	@Override
	public int deleteHtl(int htlId) throws HotelException
	{	
		return hdao.deleteHtl(htlId);
	}
	@Override
	public int addRooms(RoomDetails room) throws HotelException 
	{
		return hdao.addRooms(room);
	}
	@Override
	public String updateRoom(RoomDetails room) throws HotelException 
	{
		return hdao.updateRoom(room);
	}
	@Override
	public String deleteRoom(String roomid, String hid) throws HotelException 
	{
		return hdao.deleteRoom(roomid, hid);
	}
	@Override
	public ArrayList<Hotels> getAllHotels() throws HotelException 
	{
		return hdao.getAllHotels();
	}
	@Override
	public ArrayList<BookingDetails> viewBookingsSpecificDate(LocalDate bookdate) throws HotelException 
	{
		return hdao.viewBookingsSpecificDate(bookdate);
	}
	@Override
	public List<User> guestOfSpecificHotel(String hotelId) throws HotelException
	{
		return hdao.guestOfSpecificHotel(hotelId);
	}
	@Override
	public List<BookingDetails> specificHotelBookings(String hotelId)throws HotelException
	{
		return hdao.specificHotelBookings(hotelId);
	}

	@Override
	public boolean validateRoomId(String rid) throws HotelException 
	{
		String idPattern="[0-9]{4}";
		if(Pattern.matches(idPattern, rid))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid room id eg:1001");
		}
	}
	@Override
	public boolean validateRoomNo(String rno) throws HotelException 
	{
		String noPattern="[0-9]{3}";
		if(Pattern.matches(noPattern, rno))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid room number eg:121");
		}
	}
	@Override
	public boolean validateRoomType(String rtype) throws HotelException 
	{
		String typePattern="[AC,NON_AC]";
		if(Pattern.matches(typePattern, rtype))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid room type eg: AC/NON_AC");
		}

	}


	@Override
	public boolean validateHotelCity(String hcity) throws HotelException 
	{
		String cityPattern="[A-Z][a-z]{1,19}";
		if(Pattern.matches(cityPattern, hcity))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Only Chars allowed and starts with capital eg.Mumbai");
		}
	}
	@Override
	public boolean validateHotelAddress(String hadd) throws HotelException 
	{
		String addPattern="[A-Z][a-z]{1,19}";
		if(Pattern.matches(addPattern, hadd))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Only Chars allowed and starts with capital eg.Bandra");
		}
	}
	@Override
	public boolean validatePhone1(String ph1) throws HotelException 
	{
		String ph1Pattern="[7-9][0-9]{9}";
		if(Pattern.matches(ph1Pattern, ph1))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid phone number eg:9563245217");
		}
	}
	@Override
	public boolean validatePhone2(String ph2) throws HotelException 
	{
		String ph2Pattern="[7-9][0-9]{9}";
		if(Pattern.matches(ph2Pattern, ph2))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid phone number eg:9563245217");
		}
	}
	@Override
	public boolean validateHotelMailid(String hemail) throws HotelException 
	{
		String mailPattern="[A-Za-z0-9+_.-]+@(.+)$";
		if(Pattern.matches(mailPattern, hemail))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid email id eg- abc@gmail.com");
		}
	}
	@Override
	public boolean validateFax(String fax) throws HotelException 
	{
		String faxPattern="[0-9]{10}";
		if(Pattern.matches(faxPattern, fax))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Enter a valid fax number eg:2421214521");
		}
	}
	@Override
	public boolean validateHotelName(String hname) throws HotelException {
		String namePattern="[A-Z][a-z]{1,19}";
		if(Pattern.matches(namePattern, hname))
		{
			return true;
		}
		else
		{		
			throw new HotelException("Only Chars allowed and starts with capital eg.Taj");
		}
	}


}
