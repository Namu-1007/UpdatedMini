package com.cg.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.bean.BookingDetails;
import com.cg.bean.Hotels;
import com.cg.bean.RoomDetails;
import com.cg.bean.User;
import com.cg.exception.HotelException;
import com.cg.service.AdminService;
import com.cg.service.AdminServiceImpl;
import com.cg.service.UserService;
import com.cg.service.UserServiceImpl;


public class HotelClient 
{
	static Scanner sc=null;
	static AdminService htlSer=null;
	static UserService uSer=null;
	public static void main(String[] args) 
	{
		htlSer=new AdminServiceImpl();
		uSer=new UserServiceImpl();
		sc=new Scanner(System.in);
		while(true)
		{
			System.out.println("Login As\n1.Admin\n2.User");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1: //admin
				System.out.println("*************Enter your login credentials***************");
				System.out.println("Enter your name");
				String name=sc.next();
				System.out.println("Enter your password");
				String pass=sc.next();
				try 
				{
					if(htlSer.validateAdmName(name) && htlSer.validateAdmPass(pass))
					{
						System.out.println("You have logged in successfully .Select your preferrred operation");
						while(true)	
						{
							System.out.println("**************Operation Menu******************************"
									+ "\n1.Hotel Management\n"
									+ "2.Room Management\n3.View Reports");
							int c=sc.nextInt();
							switch(c)
							{
							case 1:System.out.println("==========HOTEL MANAGEMENT=====================\n"
									+ "1.Add Hotel\n2.Update Hotel\n3.Delete Hotel\n"
									+ "========================================================");
							System.out.println("Select your Choice ");
							int hmchoice=sc.nextInt();
							switch(hmchoice)
							{
							case 1:addHotel();
							break;
							case 2:updateHotel();
							break;
							case 3:deleteHotel();
							break;
							default: System.exit(0);
							}
							break;
							case 2:System.out.println("==============ROOM MANAGEMENT======================="
									+ "\n1.Add Rooms\n2.Update Rooms\n3.Delete Rooms\n"
									+ "========================================================");
							System.out.println("Select your Choice ");
							int roomchoice=sc.nextInt();
							switch(roomchoice)
							{
							case 1:addRoom();
							break;
							case 2:updateRoom();
							break;
							case 3:deleteRoom();
							break;
							default: System.exit(0);
							}
							break;
							case 3:System.out.println("==============Reports Menu=================="
									+ "1.View List Of Hotels"
									+ "\n2.View Bookings Of Specific hotel"
									+ "\n3.View Guest List of Specific Hotel"
									+ "\n4.View Bookings for Specified Date\n"
									+ "===========================================");
							System.out.println("Select your Choice ");
							int rprtchoice=sc.nextInt();
							switch(rprtchoice)
							{
							case 1:viewAllHotels();
							break;
							case 2:viewBookingHotel();
							break;
							case 3:viewGuestHotel();
							break;
							case 4:viewBookingDate();
							break;
							default: System.exit(0);
							}
							break;

							default:System.out.println("Thank you !! Visit again!!");
							System.exit(0);
							}
						}
					}
					else
					{
						System.err.println("Invalid Credentials!!Try Again");
					}
				}

				catch (HotelException e) 
				{
					System.out.println(e.getMessage());
				}
			case 2:System.out.println("User ");
			while(true)
			{
				System.out.println("1.Login\n2.Register\n3.Exit");
				System.out.println("Enter your Choice");
				int usrchoice=sc.nextInt();
				switch(usrchoice)
				{
				case 1:userLogin();
				break;
				case 2:userRegister();
				break;
				default:System.out.println("Thank you !! Visit again!!");
				System.exit(0);
				}
			}
			}
		}
	}
	//**************************Main Ends Here***************************//
	public static void addHotel()
	{
		System.out.println("Enter Hotel City");
		String city=sc.next();
		try {
			if(htlSer.validateHotelCity(city))
			{
				System.out.println("Enter Hotel Name");
				String hname=sc.next();
				if(htlSer.validateHotelName(hname))
				{
					System.out.println("Enter Hotel Address");
					String add=sc.next();
					sc.nextLine();
					if(htlSer.validateHotelAddress(add))
					{
						System.out.println("Enter Hotel Description");
						String des=sc.next();
						System.out.println("Enter Average Rate Per Night");
						float rate=sc.nextFloat();
						System.out.println("Enter first Phone Number");
						String fphn=sc.next();
						if(htlSer.validatePhone1(fphn))
						{
							System.out.println("Enter second Phone Number");
							String sphn=sc.next();
							if(htlSer.validatePhone2(sphn))
							{
								System.out.println("Enter Hotel Rating");
								String rating=sc.next();
								System.out.println("Enter EmailId");
								String em=sc.next();
								if(htlSer.validateHotelMailid(em))
								{
									System.out.println("Enter Fax Number");
									String fax=sc.next();
									if(htlSer.validateFax(fax))
									{

										try
										{
											Hotels htls=new Hotels(htlSer.generateHotelId(),
													city,hname,add,des,rate,fphn,sphn,rating,em,fax);
											int inserted=htlSer.addHotels(htls);
											if(inserted==1)
											{
												System.out.println("Hotel details are successfully inserted");
											}
											else
											{
												System.out.println("May be Some Exception");
											}
										} 
										catch (HotelException e) 
										{
											System.out.println(e.getMessage());
											e.printStackTrace();
										}
									}
								}
							}
						}
					}
				}
			}
		} 
		catch (HotelException e)
		{
			System.out.println(e.getMessage());
		}

	}
	//*********************************************************************//

	public static void updateHotel()
	{
		Hotels hotels = null;
		int upd = 0;
		try 
		{
			System.out.println("Enter hotel id: ");
			String hid=sc.next();

			hotels = new Hotels();
			hotels=new Hotels(hid,"a","b","c","d",1.0f,"2","3","4","e","5");
			upd=htlSer.updateHtl(hotels);
			//System.out.println("client update..." + upd);
			if( upd > 0 ){
				System.out.println("Enter Hotel City");
				String city=sc.next();
				System.out.println("Enter Hotel Name");
				String hname=sc.next();
				System.out.println("Enter Hotel Address");
				String add=sc.next();
				System.out.println("Enter Hotel Description");
				String des=sc.next();
				System.out.println("Enter Average Rate Per Night");
				float rate=sc.nextFloat();
				System.out.println("Enter first Phone Number");
				String phn1=sc.next();
				System.out.println("Enter second Phone Number");
				String phn2=sc.next();
				System.out.println("Enter Hotel Rating");
				String rating=sc.next();
				System.out.println("Enter EmailId");
				String em=sc.next();
				System.out.println("Enter Fax Number");
				String fax=sc.next();

				hotels=new Hotels(hid,city,hname,add,des,rate,phn1,phn2,rating,em,fax);
				htlSer.updateHtl(hotels);
				System.out.println("Hotel " +upd+" updated successfully!");
			}   
		} 
		catch (HotelException e) 
		{
			System.out.println(e.getMessage());
		}
	}
	//**********************************************************************//
	public static void deleteHotel()
	{
		System.out.println("Enter hotel id: ");
		int hid=sc.nextInt();
		try 
		{
			int dataDeleted=htlSer.deleteHtl(hid);
			if(dataDeleted==1)
			{
				System.out.println("Hotel Data deleted");
			}
			else
			{
				System.err.println("May be some exception has occurred while deletion");
			}
		} 
		catch (HotelException e)
		{
			System.out.println(e.getMessage());
		}
	}
	//********************Room Management************************//
	private static void addRoom()
	{
		System.out.println("Enter Hotel_Id");
		String hid=sc.next();
		System.out.println("Enter Room Id");
		String rid=sc.next();
		try {
			if(htlSer.validateRoomId(rid))
			{
				System.out.println("Enter Room number");
				String rno=sc.next();
				if(htlSer.validateRoomNo(rno))
				{
					System.out.println("Enter Room Type");
					String rtype=sc.next();
					//if(htlSer.validateRoomType(rtype))
					//{
					System.out.println("Enter room rate per night");
					double rate=sc.nextDouble();
					System.out.println("Enter room availability");
					String rav=sc.next();
					RoomDetails room=new RoomDetails(hid, rid, rno, rtype, rate, rav);
					try
					{
						int id=htlSer.addRooms(room);
						System.out.println("Room "+id+" is successfully added in the Hotel");
					}
					catch(Exception e)
					{
						e.printStackTrace();
						System.out.println("Something went wrong adding Room in the Hotel");
					}
					//}
				}
			}
		} catch (HotelException e) {
			System.out.println(e.getMessage());
		}
	}
	private static void updateRoom()
	{
		String roomupdated=null;
		System.out.println("Enter Hotel Id");
		String uhid=sc.next();
		System.out.println("Enter room Id");
		String urid=sc.next();
		System.out.println("Enter Room Number");
		String urno=sc.next();
		System.out.println("Enter Room Type");
		String urtype=sc.next();
		System.out.println("enter Room Rate Per Night");
		double urate=sc.nextDouble();
		System.out.println("Enter Room Availability");
		String urav=sc.next();
		RoomDetails rooms=new RoomDetails(uhid, urid, urno, urtype, urate, urav);
		try
		{
			roomupdated=htlSer.updateRoom(rooms);
			System.out.println("Room "+roomupdated+" updated Successfully");
		}
		catch(HotelException e)
		{
			System.out.println("Some Exception updating room detials");
		}
	}
	private static void deleteRoom()
	{
		System.out.println("Enter Hotel ID ");
		String dhid=sc.next();
		System.out.println("Enter Room Id");
		String drid=sc.next();
		try
		{
			String roomdeleted=htlSer.deleteRoom(drid,dhid);
			System.out.println("Room "+roomdeleted+" deleted Successfully");
		}
		catch(Exception e)
		{
			System.out.println("Something went wrong deleting the Room "+e.getMessage());
		}
	}
	//*********************Reports*******************//
	private static void viewAllHotels() 
	{
		try
		{
			ArrayList<Hotels> hotelList=htlSer.getAllHotels();
			System.out.println("******************************** \n"
					+"List OF All Hotels" + "\n"
					+"********************************" + "\n");
			for(Hotels ee:hotelList)
			{
				System.out.println("Hotel Id :"+ee.getHotelId()+"\n"
						+"City               :"+ee.getCity()+"\n"
						+"Name               :"+ee.getHotelName()+"\n"
						+"Address            :"+ee.getAddress()+"\n"
						+"Description        :"+ee.getDescription()+"\n"
						+"Average Rate/Night :"+ee.getAvgRate()+"\n"
						+"Phone Number 1     :"+ee.getPh1()+"\n"
						+"Phone Number2      :"+ee.getPh2()+"\n"
						+"Hotel Rating       :"+ee.getRating()+"\n"
						+"Email Id           :"+ee.getEmail()+"\n"
						+"Fax Number         :"+ee.getFax()+"\n"
						);
				System.out.println();
			}
		}
		catch (HotelException e) 
		{
			System.out.println("Some exception occured while fetching");
			e.printStackTrace();
		}
	}
	private static void viewBookingHotel()
	{
		System.out.println("Enter Hotel Id ");
		String hotelid=sc.next();
		System.out.println("************Bookings Of Specific Hotel**********");
		try
		{
			ArrayList<BookingDetails>hotelBookings=(ArrayList<BookingDetails>) 
					htlSer.specificHotelBookings(hotelid);
			for (BookingDetails book : hotelBookings) {
				System.out.println("=================================" + "\n"
						+ "Specific Hotel Booking Details" + "\n"
						+ "===============================" + "\n"
						+ "Booking ID  : " + book.getId() + "\n" 
						+ "Room ID     : " + book.getRoomId() + "\n" 
						+ "User ID     : " + book.getUserId() + "\n"
						+ "Booked From : " +book.getBookFrom() + "\n" 
						+ "Booked To   : " + book.getBookTo() + "\n" 
						+ "Adults      : " +book.getNoOfAdults() + "\n"
						+ "Childrens   : " + book.getNoOfChildren() + "\n"
						+ "Amount      : " + book.getAmount());
				System.out.println();
			}
		} 
		catch (HotelException e) 
		{
			System.out.println("Something went wrong. Reason " + e.getMessage());
		}
	}
	private static void viewGuestHotel()
	{
		System.out.println("Enter Hotel ID : ");
		String hid = sc.next();
		try 
		{
			List<User> user = htlSer.guestOfSpecificHotel(hid);
			for(User usrinfo:user)
			{
				System.out.println("********************************" + "\n"
						+"Guest List Of Specific Hotel" + "\n"
						+"********************************" + "\n"
						+ "User ID   : " +usrinfo.getId() + "\n"
						+ "Password  : " +usrinfo.getPassword() + "\n"
						+ "Role      : " +usrinfo.getRole() + "\n" 
						+ "User Name : " +usrinfo.getName() + "\n"
						+ "Mobile No : " +usrinfo.getMobileNumber() + "\n"
						+ "Phone No  : " +usrinfo.getPhoneNumber() + "\n"
						+ "Address   : " +usrinfo.getAddress() + "\n"
						+ "Email ID  : " +usrinfo.getEmail());

				System.out.println();

			}
		} 
		catch (HotelException e) 
		{
			System.out.println("Some exception might have occurred."+e.getMessage());
		}
	}
	private static void viewBookingDate()
	{
		System.out.print("Enter a date: ");
		String bDate = sc.next();
		DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate bookingDate = LocalDate.parse(bDate, format);
		System.out.println("************Bookings OF Specified Date**************");
		try
		{
			ArrayList<BookingDetails>bookings=htlSer.viewBookingsSpecificDate(bookingDate);
			for(BookingDetails bdetails:bookings)
			{
				System.out.println("Booking Id: "+bdetails.getId()+"\n"
						+ "Room Id: "+bdetails.getRoomId()+"\n"
						+ "User Id : " + bdetails.getUserId() + "\n"
						+ "Check In Date  : " + bdetails.getBookFrom() + "\n" 
						+ "Check Out Date : " + bdetails.getBookTo() + "\n" 
						+ "No Of Adults   : " + bdetails.getNoOfAdults() + "\n"
						+ "No Of Children : " + bdetails.getNoOfChildren() + "\n" 
						+ "Total Amount   : " + bdetails.getAmount());
			}
		}
		catch(HotelException he)
		{
			System.out.println("Some Exception occured while fetching the book details"+he.getMessage());
		}
	}
	//*********************User Menu******************
	private static void userLogin()
	{
		boolean status = false;
		System.out.println("*******************Welcome to login page********************");
		System.out.println("Enter your login Id");
		String id=sc.next();
		System.out.println("Enter password");
		String password = sc.next();
		User user= new User(id,password);
		try 
		{
			status = uSer.login(user);
			if(status)
			{
				System.out.println("You have Logged in successfully Now You can perform operations!!");
				System.out.println("1.Book Hotel Rooms\n2.Search Hotel\n3.View Booking Status\n4.Exit");
				System.out.println("Select Your Choice");
				int opchoice=sc.nextInt();
				switch(opchoice)
				{
				case 1: bookHotel();
				break;
				case 2: searchHotel();
				break;
				case 3: bookingStatus();
				break;
				default:System.out.println("Thank You For Visiting!!");
				System.exit(0);     
				}
			}
			else
			{
				System.out.println("Invalid Credentials. Please try again.");
			}
		} 
		catch (HotelException e)
		{
			System.out.println("Some exception while logging in"+e.getMessage());
		}
	}

	private static void userRegister()
	{
		System.out.println("***********Welcome to Registration Page****************");
		System.out.println("Enter user id");
		String uid=sc.next();
		System.out.println("Enter user name");
		String uname=sc.next();
		System.out.println("Enter password");
		String upass=sc.next();
		System.out.println("Enter email address");
		String umail=sc.next();
		System.out.println("Enter your mobile number");
		String umob=sc.next();
		System.out.println("Enter your phone number");
		String uphn=sc.next();
		System.out.println("Enter your role");
		String urole=sc.next();
		System.out.println("Enter your address");
		String uadd=sc.next();
		User usr= new User();
		try 
		{
			usr.setId(uid);
			usr.setPassword(upass);
			usr.setRole(urole);
			usr.setName(uname);
			usr.setMobileNumber(umob);
			usr.setPhoneNumber(uphn);
			usr.setAddress(uadd);
			usr.setEmail(umail);
			int dataAdded = uSer.registerUser(usr);
			if(dataAdded==1)
			{
				System.out.println("Registered Successfully");
				userLogin();
			}
			else
			{
				System.out.println("Some error while registering.");
			}
		} 
		catch (HotelException e) 
		{
			System.out.println("May be some exception during registration");
		}


	}

	private static void searchHotel()
	{
		System.out.println("Enter the city where you want to book a hotel");
		String city=sc.next();
		try
		{
			ArrayList<Hotels>hList=new ArrayList<Hotels>();
			hList=uSer.searchAllHotels(city);
			System.out.println("********List Of Hotels in "+city+"**********");
			for(Hotels hotel:hList)
			{
				System.out.println("Hotel Id :"+hotel.getHotelId()+"\n"
						+"City               :"+hotel.getCity()+"\n"
						+"Name               :"+hotel.getHotelName()+"\n"
						+"Address            :"+hotel.getAddress()+"\n"
						+"Description        :"+hotel.getDescription()+"\n"
						+"Average Rate/Night :"+hotel.getAvgRate()+"\n"
						+"Phone Number 1     :"+hotel.getPh1()+"\n"
						+"Phone Number2      :"+hotel.getPh2()+"\n"
						+"Hotel Rating       :"+hotel.getRating()+"\n"
						+"Email Id           :"+hotel.getEmail()+"\n"
						+"Fax Number         :"+hotel.getFax()+"\n"
						);
				System.out.println();
			}
		}
		catch(HotelException e)
		{
			System.out.println("Sorry!!We don't have any branch in this Location");
		}
	}
	private static void bookHotel()
	{
		System.out.println("Enter Hotel Name :");
		sc.nextLine();
		String hotelname = sc.nextLine();
		try 
		{
			List<RoomDetails> roomList = new ArrayList<>();
			roomList = uSer.showRooms(hotelname);
			System.out.println("*******Available Rooms In Hotel "+hotelname+"******");
			for (RoomDetails roomDetails : roomList) 
			{
				System.out.println("Room Id: "+roomDetails.getId()+"\n"
						+ "Room No: "+roomDetails.getNumber()+"\n"
						+ "Room Type: "+roomDetails.getType()+"\n"
						+ "PerNightRate: "+roomDetails.getPerNightRate()+"\n"
						+ "***********************************************");
			}
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		System.out.print("Enter Room Id: ");
		String roomId = sc.next();
		System.out.print("Enter User Id: ");
		String userId=sc.next();
		System.out.print("Enter book date from: ");
		String bookFrom = sc.next();
		System.out.print("Enter book date to: ");
		String bookTo = sc.next();
		System.out.print("Enter No of adults: ");
		int adults = sc.nextInt();
		System.out.print("Enter No of Children: ");
		int childrens = sc.nextInt();

		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		LocalDate fromDate = LocalDate.parse(bookFrom, formatter);
		LocalDate toDate = LocalDate.parse(bookTo, formatter);
		try 
		{
			if(uSer.validateDate(fromDate, toDate)){

				double amount=uSer.generateBill(roomId, fromDate, toDate);
				System.out.println("Your Total bill is : "+amount);
				System.out.println("To confirm press Y else N");
				String ch = sc.next();
				if(ch.equals("Y") || ch.equals("y"))
				{
					BookingDetails bookingdetails = new BookingDetails(roomId, userId, 
							fromDate, toDate, adults, childrens,amount);
					int bookID = uSer.bookHotel(bookingdetails);
					//System.out.println("booki id is..."+bookID);
					if(bookID > 0)
					{
						System.out.println("Booking successfull. Your Booking ID: " + bookID);
					}
					else
					{
						System.out.println("Room is not available for this date.");
						System.exit(0);
					}
				}
				else{
					System.out.println("No operation performed!");
				}
			}
			else{
				System.out.println("Booked Till date should be greater than booked from date");
			}
		}
		catch (HotelException e) 
		{
			e.printStackTrace();
			System.out.println("Something went wrong. Reason" + e.getMessage());
		}
	}

	private static void bookingStatus()
	{
		System.out.println("Enter Booking Id");
		String bookId=sc.next();
		try 
		{
			if(!bookId.equals(0))
			{
				//System.out.println("Booking status: Booked");
				ArrayList<BookingDetails> bookList=uSer.getBookingStatus(bookId);
				for(BookingDetails bk:bookList) 
				{
					System.out.println("==========Your Booking Ddetails======\n"
							+ "Room Id: "+bk.getRoomId()+"\n"
							+ "User Id : " + bk.getUserId() + "\n"
							+ "Check In Date  : " + bk.getBookFrom() + "\n" 
							+ "Check Out Date : " + bk.getBookTo() + "\n" 
							+ "No Of Adults   : " + bk.getNoOfAdults() + "\n"
							+ "No Of Children : " + bk.getNoOfChildren() + "\n" 
							+ "Total Amount   : " + bk.getAmount());
				}
			}
			else
			{
				System.out.println("Booking status: Available");
			}
		} 
		catch (HotelException e)
		{
			System.out.println("Some exception while fetching data");
			e.printStackTrace();
		}
	}
}


